# OpenZeppelin Contracts

The files in this directory were sourced unmodified from OpenZeppelin Contracts v4.4.1.

They are not meant to be edited.

The originals can be found on [GitHub] and [npm].

[GitHub]: https://github.com/OpenZeppelin/openzeppelin-contracts/tree/v4.4.1
[npm]: https://www.npmjs.com/package/@openzeppelin/contracts/v/4.4.1

Generated with OpenZeppelin Contracts Wizard (https://zpl.in/wizard).
